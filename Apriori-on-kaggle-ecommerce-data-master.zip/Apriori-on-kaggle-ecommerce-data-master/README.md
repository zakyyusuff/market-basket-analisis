# Apriori on kaggle ecommerce data
This project is showing how to use R to implement association rules, which is used to find frequent itemsets. I came across this concept when reading the book data minining. concepts and techniques. You can find the code [here](https://github.com/xgao0412/Apriori-on-kaggle-ecommerce-data/blob/master/ecommerce.Rmd)

